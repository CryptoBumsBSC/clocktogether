/**
 * ClockTogether — Interactive landing page logic
 *
 * Renders the live world map, day/night terminator, city markers, and free converter
 * shown in the hero section of clocktogether.com.
 *
 * Architecture:
 *   1. Map setup runs once on script load (projection, defs, background, graticule)
 *   2. Country shapes load asynchronously from CDN (world-atlas TopoJSON)
 *   3. Day/night terminator + city markers redraw every minute on the minute
 *   4. Converter runs entirely client-side via Luxon
 *
 * Dependencies (loaded via CDN in index.html):
 *   - Luxon 3.5         — IANA timezone math, DST handling, locale formatting
 *   - D3 v7             — SVG / geo projection / geo path
 *   - topojson-client 3 — TopoJSON → GeoJSON conversion
 *
 * Globals consumed (from cities.js):
 *   - window.CITIES           Array<City>
 *   - window.FEATURED_CITIES  Array<string>  (subset of CITIES, shown on map)
 *
 * Where to make changes:
 *   - To add/remove cities: edit cities.js
 *   - To change brand colour: edit COLOURS.home / index.html CSS vars
 *   - To change refresh cadence: edit REFRESH_MS
 *   - To change projection (e.g. to Mercator): edit createProjection()
 */
(function () {
  'use strict';

  // ====================================================================
  // CONSTANTS
  // ====================================================================

  const { DateTime } = luxon;

  /** Map SVG dimensions in viewBox units (independent of rendered size). */
  const MAP_WIDTH  = 1000;
  const MAP_HEIGHT = 500;

  /** Source of world country shapes. */
  const ATLAS_URL = 'https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json';

  /** How often the map refreshes its day/night + city times. */
  const REFRESH_MS = 60_000;

  /** Time constants for readability. */
  const MS_PER_DAY  = 86_400_000;
  const MS_PER_HOUR = 3_600_000;
  const MS_PER_MIN  =     60_000;

  /** Colour palette — kept in sync with index.html CSS variables. */
  const COLOURS = {
    home:           '#1D9E75',
    sunOuter:       '#FFD56B',
    sunCore:        '#FFE9A8',
    day:            '#FFD56B',
    dawn:           '#FF9577',
    night:          '#8FA4D4',
    homeLabel:      '#ffffff',
    landFill:       '#2A5A45',
    landStroke:     '#0F3D2E',
    graticule:      'rgba(255,255,255,0.04)',
    nightOverlay:   'rgba(8, 18, 36, 0.55)',
    twilightBand:   'rgba(255, 140, 90, 0.12)',
    labelStroke:    'rgba(6, 24, 15, 0.9)',
    labelDimText:   'rgba(255,255,255,0.78)',
  };

  /** Hour-of-day buckets that determine a city's marker colour. */
  const DAY_BAND = { startHour: 7,  endHour: 18 };  // 07:00–17:59
  const DAWN_BAND_MORNING = { startHour: 5, endHour: 7 };
  const DAWN_BAND_EVENING = { startHour: 18, endHour: 20 };

  // ====================================================================
  // RUNTIME STATE
  // ====================================================================

  /** Cached DOM references — populated once in cacheDOM(). */
  const DOM = {
    map:             null,
    mapLoader:       null,
    convFrom:        null,
    convTo:          null,
    convDate:        null,
    convTime:        null,
    convBtn:         null,
    convResult:      null,
    convHelper:      null,
    converterSection: null,
  };

  /** D3 selection groups for layered drawing. */
  const layers = {
    countries: null,
    night:     null,
    cities:    null,
    labels:    null,
  };

  /** Geo projection (created in setupMap). */
  let projection = null;
  let geoPath = null;

  /** The user's home city, determined once from browser timezone. */
  const HOME_CITY = findHomeCity();

  /** Holds the most recent conversion result so the Copy button can read it. */
  let lastResult = null;

  // ====================================================================
  // PURE HELPERS
  // ====================================================================

  /**
   * Returns the user's home City object by matching the browser's IANA timezone.
   * Falls back to London → CITIES[0] if no match (e.g. for unusual timezones).
   * @returns {Object} City
   */
  function findHomeCity() {
    const browserTZ = (Intl.DateTimeFormat().resolvedOptions().timeZone) || 'UTC';
    return CITIES.find(c => c.tz === browserTZ)
        || CITIES.find(c => c.name === 'London')
        || CITIES[0];
  }

  /**
   * Returns 'day' | 'dawn' | 'night' for a given local hour (0–23).
   * @param {number} hour
   * @returns {'day'|'dawn'|'night'}
   */
  function timeBand(hour) {
    if (hour >= DAY_BAND.startHour && hour < DAY_BAND.endHour) return 'day';
    if ((hour >= DAWN_BAND_MORNING.startHour && hour < DAWN_BAND_MORNING.endHour) ||
        (hour >= DAWN_BAND_EVENING.startHour && hour < DAWN_BAND_EVENING.endHour)) return 'dawn';
    return 'night';
  }

  /**
   * Computes the longitude and latitude of the subsolar point —
   * the place on Earth where the sun is currently directly overhead.
   * Used to drive the day/night terminator on the map.
   * Accuracy: ±1° latitude (good enough for visualisation).
   * @returns {[number, number]} [longitude, latitude]
   */
  function subsolarPoint() {
    const now = new Date();
    const dayOfYear = Math.floor(
      (now - new Date(Date.UTC(now.getUTCFullYear(), 0, 0))) / MS_PER_DAY
    );
    // Sun declination — annual sine wave between ±23.45°
    const declination = 23.45 * Math.sin(2 * Math.PI * (284 + dayOfYear) / 365);
    // At UTC noon, the sun is over 0° longitude. Each UTC hour ≈ 15° east/west.
    const utcHours = now.getUTCHours() + now.getUTCMinutes() / 60;
    const longitude = -((utcHours - 12) * 15);
    return [longitude, declination];
  }

  /**
   * Builds a friendly "in 2d 4h" countdown string from a millisecond delta.
   * @param {number} diffMs
   * @returns {string}
   */
  function formatCountdown(diffMs) {
    if (diffMs <= 0) return 'in the past';
    const days  = Math.floor(diffMs / MS_PER_DAY);
    const hours = Math.floor((diffMs % MS_PER_DAY)  / MS_PER_HOUR);
    const mins  = Math.floor((diffMs % MS_PER_HOUR) / MS_PER_MIN);
    if (days  > 0) return `in ${days}d ${hours}h`;
    if (hours > 0) return `in ${hours}h ${mins}m`;
    return `in ${mins}m`;
  }

  // ====================================================================
  // MAP SETUP (runs once)
  // ====================================================================

  /**
   * Sets up the SVG container, projection, defs, and background layers.
   * Idempotent on the layer groups (creates them only on first call).
   */
  function setupMap() {
    const svg = DOM.map.attr('viewBox', `0 0 ${MAP_WIDTH} ${MAP_HEIGHT}`);

    projection = d3.geoEquirectangular()
      .scale(MAP_WIDTH / (2 * Math.PI))
      .translate([MAP_WIDTH / 2, MAP_HEIGHT / 2]);

    geoPath = d3.geoPath(projection);

    // <defs> — reusable filter for the sun glow
    const defs = svg.append('defs');
    defs.append('filter')
      .attr('id', 'cityGlow')
      .attr('x', '-50%').attr('y', '-50%')
      .attr('width', '200%').attr('height', '200%')
      .append('feGaussianBlur').attr('stdDeviation', '2.5');

    // Radial background gradient (centre brighter than edges)
    const bg = defs.append('radialGradient')
      .attr('id', 'mapBgGrad')
      .attr('cx', '50%').attr('cy', '40%').attr('r', '70%');
    bg.append('stop').attr('offset',   '0%').attr('stop-color', '#0F3D2E');
    bg.append('stop').attr('offset', '100%').attr('stop-color', '#06180F');

    // Background rectangle
    svg.append('rect')
      .attr('width', MAP_WIDTH).attr('height', MAP_HEIGHT)
      .attr('fill', 'url(#mapBgGrad)');

    // Graticule (subtle 30° lat/lng grid)
    svg.append('g').attr('class', 'graticule')
      .append('path')
      .datum(d3.geoGraticule().step([30, 30]))
      .attr('d', geoPath)
      .attr('fill', 'none')
      .attr('stroke', COLOURS.graticule)
      .attr('stroke-width', 0.5);

    // Layered groups (drawn in this order: countries → night → cities → labels)
    layers.countries = svg.append('g').attr('class', 'countries');
    layers.night     = svg.append('g').attr('class', 'night');
    layers.cities    = svg.append('g').attr('class', 'cities');
    layers.labels    = svg.append('g').attr('class', 'labels');
  }

  /**
   * Fetches world country shapes from the CDN and draws them.
   * On failure, falls through to draw cities + day/night without country fills.
   */
  function loadCountries() {
    return fetch(ATLAS_URL)
      .then(r => r.json())
      .then(world => {
        const countries = topojson.feature(world, world.objects.countries);
        layers.countries.selectAll('path')
          .data(countries.features).enter()
          .append('path')
            .attr('d', geoPath)
            .attr('fill', COLOURS.landFill)
            .attr('stroke', COLOURS.landStroke)
            .attr('stroke-width', 0.4)
            .attr('opacity', 0.85);
      })
      .catch(err => {
        console.warn('[ClockTogether] World atlas failed to load; rendering markers only.', err);
      });
  }

  // ====================================================================
  // MAP DRAWING (called on every tick)
  // ====================================================================

  /**
   * Draws the dark night overlay, twilight band, and sun marker.
   * Wipes and redraws the night layer each call.
   */
  function drawDayNight() {
    const [subLng, subLat] = subsolarPoint();
    layers.night.selectAll('*').remove();

    // Night = world minus day hemisphere (even-odd fill)
    const dayHemisphere = d3.geoCircle().center([subLng, subLat]).radius(90)();
    const worldRect = geoPath({
      type: 'Polygon',
      coordinates: [[
        [-179.99, -89.99], [179.99, -89.99],
        [ 179.99,  89.99], [-179.99,  89.99],
        [-179.99, -89.99]
      ]]
    });
    const dayPath = geoPath(dayHemisphere);
    if (worldRect && dayPath) {
      layers.night.append('path')
        .attr('d', worldRect + ' ' + dayPath)
        .attr('fill', COLOURS.nightOverlay)
        .attr('fill-rule', 'evenodd')
        .attr('pointer-events', 'none');
    }

    // Twilight band — soft warm ring near the day/night boundary
    const twilightInner = d3.geoCircle().center([subLng, subLat]).radius(87)();
    const twilightOuter = d3.geoCircle().center([subLng, subLat]).radius(93)();
    const inner = geoPath(twilightInner);
    const outer = geoPath(twilightOuter);
    if (inner && outer) {
      layers.night.append('path')
        .attr('d', outer + ' ' + inner)
        .attr('fill', COLOURS.twilightBand)
        .attr('fill-rule', 'evenodd')
        .attr('pointer-events', 'none');
    }

    // Sun marker — three nested glow layers
    const sunCoords = projection([subLng, subLat]);
    if (!sunCoords) return;
    const sunLayers = [
      { r: 22, fill: COLOURS.sunOuter, opacity: 0.25, glow: true },
      { r: 14, fill: COLOURS.sunOuter, opacity: 0.60, glow: true },
      { r:  7, fill: COLOURS.sunCore,  opacity: 1.00, glow: false },
    ];
    sunLayers.forEach(L => {
      const c = layers.night.append('circle')
        .attr('cx', sunCoords[0]).attr('cy', sunCoords[1])
        .attr('r', L.r).attr('fill', L.fill).attr('opacity', L.opacity)
        .attr('pointer-events', 'none');
      if (L.glow) c.attr('filter', 'url(#cityGlow)');
    });
  }

  /**
   * Draws each featured city as a clickable marker with name + local time label.
   * Wipes and redraws both city and label layers each call.
   */
  function drawCities() {
    layers.cities.selectAll('*').remove();
    layers.labels.selectAll('*').remove();

    const featured = CITIES.filter(c => FEATURED_CITIES.includes(c.name));
    featured.forEach(drawCityMarker);
  }

  /**
   * @param {Object} city
   */
  function drawCityMarker(city) {
    const coords = projection([city.lng, city.lat]);
    if (!coords) return;

    const localTime = DateTime.now().setZone(city.tz);
    const band      = timeBand(localTime.hour);
    const bandHex   = COLOURS[band];
    const isHome    = (city.name === HOME_CITY.name);
    const dotColour = isHome ? COLOURS.home : bandHex;

    // Group catches the click; nested shapes are decorative
    const group = layers.cities.append('g')
      .attr('class', 'city-marker')
      .attr('data-city', city.name)
      .style('cursor', 'pointer')
      .on('click', () => openConverterFor(city));

    // Outer ring
    group.append('circle')
      .attr('cx', coords[0]).attr('cy', coords[1])
      .attr('r', isHome ? 14 : 10)
      .attr('fill', 'none')
      .attr('stroke', dotColour)
      .attr('stroke-width', isHome ? 3 : 1.5)
      .attr('opacity', isHome ? 1 : 0.55);

    // Animated pulse — home city only
    if (isHome) {
      group.append('circle')
        .attr('cx', coords[0]).attr('cy', coords[1])
        .attr('r', 14)
        .attr('fill', 'none')
        .attr('stroke', COLOURS.home)
        .attr('stroke-width', 2)
        .style('transform-origin', `${coords[0]}px ${coords[1]}px`)
        .style('animation', 'cityPulse 2.4s ease-out infinite');
    }

    // Solid centre dot
    group.append('circle')
      .attr('cx', coords[0]).attr('cy', coords[1])
      .attr('r', isHome ? 7 : 5)
      .attr('fill', dotColour)
      .attr('filter', band === 'day' ? 'url(#cityGlow)' : null);

    // Labels — name + time, with stroke for legibility over varied backgrounds
    const labelGroup = layers.labels.append('g').style('pointer-events', 'none');
    const labelY = coords[1] - (isHome ? 24 : 18);

    const labelName = (city.name === HOME_CITY.name)
      ? `${city.name.toUpperCase()} (you)`
      : city.name.toUpperCase();

    labelGroup.append('text')
      .attr('x', coords[0]).attr('y', labelY - 18)
      .attr('text-anchor', 'middle')
      .attr('font-family', "'JetBrains Mono', monospace")
      .attr('font-size',   isHome ? '20px' : '16px')
      .attr('font-weight', isHome ? '600'  : '500')
      .attr('fill', isHome ? COLOURS.homeLabel : COLOURS.labelDimText)
      .style('paint-order',  'stroke')
      .style('stroke',       COLOURS.labelStroke)
      .style('stroke-width', '4px')
      .text(labelName);

    labelGroup.append('text')
      .attr('x', coords[0]).attr('y', labelY)
      .attr('text-anchor', 'middle')
      .attr('font-family', "'JetBrains Mono', monospace")
      .attr('font-size',   isHome ? '22px' : '18px')
      .attr('font-weight', '700')
      .attr('fill', isHome ? COLOURS.home : bandHex)
      .style('paint-order',  'stroke')
      .style('stroke',       COLOURS.labelStroke)
      .style('stroke-width', '4px')
      .text(localTime.toFormat('HH:mm'));
  }

  // ====================================================================
  // LIVE TICKER
  // ====================================================================

  /** Redraws day/night + city markers. */
  function tick() {
    drawDayNight();
    drawCities();
  }

  /**
   * Starts the live ticker, aligned to the next real minute boundary
   * so visible clock changes happen at the same moment as the user's wall clock.
   */
  function startTicker() {
    const msToNextMinute = REFRESH_MS - (Date.now() % REFRESH_MS);
    setTimeout(() => {
      tick();
      setInterval(tick, REFRESH_MS);
    }, msToNextMinute);
  }

  // ====================================================================
  // CONVERTER
  // ====================================================================

  /**
   * Populates a <select> with the full CITIES list, formatted "Name, Country".
   * @param {HTMLSelectElement} select
   */
  function populateCityDropdown(select) {
    if (!select) return;
    const frag = document.createDocumentFragment();
    CITIES.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c.name;
      opt.textContent = `${c.name}, ${c.country}`;
      frag.appendChild(opt);
    });
    select.replaceChildren(frag);
  }

  /** Sets sensible default values for the converter form. */
  function setConverterDefaults() {
    populateCityDropdown(DOM.convFrom);
    populateCityDropdown(DOM.convTo);

    // From defaults to Sydney (good global example); To defaults to user's home
    if (DOM.convFrom) DOM.convFrom.value = 'Sydney';
    if (DOM.convTo)   DOM.convTo.value   = HOME_CITY.name;

    // Date defaults to tomorrow, time defaults to 09:00
    if (DOM.convDate) DOM.convDate.value = DateTime.now().plus({ days: 1 }).toFormat('yyyy-MM-dd');
    if (DOM.convTime) DOM.convTime.value = '09:00';
  }

  /**
   * Reads the form, converts the meeting time, and renders the result.
   */
  function convertMeeting() {
    const fromName = DOM.convFrom?.value;
    const toName   = DOM.convTo?.value;
    const dateStr  = DOM.convDate?.value;
    const timeStr  = DOM.convTime?.value;
    if (!fromName || !toName || !dateStr || !timeStr) return;

    const from = CITIES.find(c => c.name === fromName);
    const to   = CITIES.find(c => c.name === toName);
    if (!from || !to) return;

    const sourceDT = DateTime.fromISO(`${dateStr}T${timeStr}`, { zone: from.tz });
    if (!sourceDT.isValid) return;

    const localDT = sourceDT.setZone(to.tz);
    renderResult(from, sourceDT, to, localDT);
  }

  /**
   * Builds the result block HTML and inserts it into the DOM.
   * @param {Object} fromCity
   * @param {luxon.DateTime} fromDT
   * @param {Object} toCity
   * @param {luxon.DateTime} toDT
   */
  function renderResult(fromCity, fromDT, toCity, toDT) {
    if (!DOM.convResult) return;

    const fmt = dt => ({
      day:  dt.toFormat('EEEE'),
      date: dt.toFormat('d LLLL yyyy'),
      time: dt.toFormat('h:mm a'),
      zone: dt.toFormat('ZZZZ'),
    });
    const f = fmt(fromDT);
    const t = fmt(toDT);

    // Day-rollover detection — alert the user if dates differ between zones
    const fromDayKey = Math.floor(fromDT.toMillis() / MS_PER_DAY);
    const toDayKey   = Math.floor(toDT.toMillis()   / MS_PER_DAY);
    const dayRollover = fromDayKey !== toDayKey;
    const rolloverHTML = dayRollover
      ? `<div class="rollover">⚠ Day changes — ${fromCity.name} ${f.day.toLowerCase()} = ${toCity.name} ${t.day.toLowerCase()}</div>`
      : '';

    const countdownText = formatCountdown(fromDT.toMillis() - Date.now());

    DOM.convResult.innerHTML = `
      <div class="result-eye">✓ Converted</div>
      <div class="time-pair">
        <div class="tp-block">
          <span class="tp-l">Meeting time</span>
          <span class="tp-d">${f.day}</span>
          <span class="tp-date">${f.date}</span>
          <span class="tp-t">${f.time}</span>
          <span class="tp-z">${fromCity.name} · ${f.zone}</span>
        </div>
        <div class="tp-block r">
          <span class="tp-l">Your time</span>
          <span class="tp-d">${t.day}</span>
          <span class="tp-date">${t.date}</span>
          <span class="tp-t">${t.time}</span>
          <span class="tp-z">${toCity.name} · ${t.zone}</span>
        </div>
      </div>
      ${rolloverHTML}
      <div class="result-meta">
        <span class="cd-pill">${countdownText}</span>
        <button class="copy-btn" id="result-copy-btn" type="button">Copy ↗</button>
      </div>
      <div class="upsell">
        <span class="upsell-text">Save this meeting + invite your team</span>
        <a class="upsell-link" href="#signup">Free signup →</a>
      </div>
    `;
    DOM.convResult.classList.add('visible');

    // Cache the result for the Copy button + wire its handler
    lastResult = { fromCity, fromDT, toCity, toDT, countdownText };
    const copyBtn = document.getElementById('result-copy-btn');
    if (copyBtn) copyBtn.addEventListener('click', copyResultToClipboard);

    DOM.convResult.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  /**
   * Copies the last conversion result to the clipboard as plain text.
   */
  function copyResultToClipboard() {
    if (!lastResult) return;
    const { fromCity, fromDT, toCity, toDT, countdownText } = lastResult;
    const text = [
      '📅 Meeting time',
      '',
      `Source:    ${fromDT.toFormat('EEEE d LLLL yyyy · h:mm a')} ${fromCity.name} (${fromDT.toFormat('ZZZZ')})`,
      `Your time: ${toDT.toFormat('EEEE d LLLL yyyy · h:mm a')} ${toCity.name} (${toDT.toFormat('ZZZZ')})`,
      `Countdown: ${countdownText}`,
      '',
      '— Converted with ClockTogether',
    ].join('\n');

    navigator.clipboard.writeText(text)
      .then(() => flashCopyButton('Copied ✓'))
      .catch(() => flashCopyButton('Copy failed'));
  }

  /**
   * Briefly changes the copy button's text to give feedback after click.
   * @param {string} message
   */
  function flashCopyButton(message) {
    const btn = document.getElementById('result-copy-btn');
    if (!btn) return;
    const original = btn.textContent;
    btn.textContent = message;
    setTimeout(() => { btn.textContent = original; }, 1800);
  }

  /**
   * Click handler for city markers — pre-fills the converter and runs it.
   * @param {Object} city
   */
  function openConverterFor(city) {
    if (DOM.convFrom) DOM.convFrom.value = city.name;
    if (DOM.converterSection) {
      DOM.converterSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    convertMeeting();
  }

  // ====================================================================
  // BOOTSTRAP
  // ====================================================================

  /**
   * Populates the DOM cache with frequently-used elements.
   * Called once on DOMContentLoaded.
   */
  function cacheDOM() {
    DOM.map              = d3.select('#world-map');
    DOM.mapLoader        = document.getElementById('map-loader');
    DOM.convFrom         = document.getElementById('conv-from');
    DOM.convTo           = document.getElementById('conv-to');
    DOM.convDate         = document.getElementById('conv-date');
    DOM.convTime         = document.getElementById('conv-time');
    DOM.convBtn          = document.getElementById('conv-btn');
    DOM.convResult       = document.getElementById('conv-result');
    DOM.convHelper       = document.getElementById('home-tz-label');
    DOM.converterSection = document.querySelector('.converter');
  }

  /** Hides the map loading message once initial paint is done. */
  function hideMapLoader() {
    if (DOM.mapLoader) DOM.mapLoader.style.display = 'none';
  }

  /** Entry point — wires everything up. */
  function init() {
    cacheDOM();
    setupMap();
    setConverterDefaults();

    if (DOM.convBtn) DOM.convBtn.addEventListener('click', convertMeeting);
    if (DOM.convHelper) {
      DOM.convHelper.textContent = `Detected: ${HOME_CITY.name}, ${HOME_CITY.country}`;
    }

    loadCountries().finally(() => {
      tick();           // First draw — day/night + cities
      hideMapLoader();  // Reveal the populated map
      startTicker();    // Schedule subsequent minute-aligned redraws
    });

    // Auto-convert with default values so the result block isn't empty on first load
    setTimeout(convertMeeting, 100);
  }

  document.addEventListener('DOMContentLoaded', init);
})();
