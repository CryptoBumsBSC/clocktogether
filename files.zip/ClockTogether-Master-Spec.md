# ClockTogether — Master Specification

**Last updated:** 19 May 2026
**Status:** Spec locked, ready for build
**Owner:** Oscar James (AussieBoomer)

> **Re-open this document at the start of every new session** so the build picks up exactly where it left off. Container resets between sessions wipe everything except this spec.

---

## Quick reference

| | |
|---|---|
| **Domain** | clocktogether.com (locked on GoDaddy) |
| **Hosting** | Speed Reaper shared hosting |
| **Stack** | PHP / MySQL (same as Yakkafy) |
| **Payments** | Stripe AU (stripe.com/au) |
| **Email** | Resend (with SMTP fallback) |
| **Telegram bot** | @MeetingTimeConverterbot (already live, registered in BotFather) |
| **Colour** | #1D9E75 (teal) primary, light theme |
| **Build status** | All files built across prior sessions, container reset wiped them — rebuild required |

---

## Vision

**One-line:** A multi-timezone meeting scheduler that solves the "what time is it in your zone?" problem for global teams, with full Telegram Mini App integration so it lives where conversations already happen.

**Distribution channels:** clocktogether.com (web/PWA), Telegram Mini App, optional pin in any Telegram group.

---

## LOCKED DESIGN RULES — apply globally, no exceptions

These rules apply everywhere a time or meeting appears (cards, detail view, share text, bot pin, email, archive, notification toast):

### 1. Dual-time display
Every meeting display shows **both** the source meeting time AND the user's local time, with equal visual weight. Neither dominates. Both labelled clearly ("Meeting time" / "Your time").

### 2. Full format
Every time display shows: **day name + date + time + timezone abbreviation**.
- ✅ `Tuesday · 20 May 2026 · 9:00 AM · Sydney AEDT`
- ❌ `Tue 9:00 AM`
- ❌ `9am Sydney`

Date format follows user locale automatically (AU: `20 May 2026`, US: `May 20, 2026`, EU: `20.05.2026`).

### 3. 7-meeting limit (split)
- **7 personal meetings per user** (works for solo users + team members)
- **7 meetings per team** they belong to (separate bucket)
- Both buckets are independent — being in 3 teams = 7 personal + 7×3 team = up to 28 total slots

### 4. Owner-only team meeting control
Only team owner or designated admin can create or edit team meetings. Members can view, accept/decline, share, copy. Personal meetings are always user-controlled.

### 5. In-app sync only
When a meeting time changes:
- Other members see it on next app open
- Auto-refresh every 60 seconds while app is open
- No email notification
- No push notification
- No Telegram DM (bot may edit a group-pinned message — that's separate)
- "Updated 5m ago" badge appears on the card for 24 hours

### 6. Past meetings auto-archive
Once a meeting's datetime passes, it moves to archive. The 7-slot count only includes upcoming meetings. Archive still browsable, both original times preserved.

### 7. DST handling — lock-clock-time (default)
If a meeting is "9am Sydney" and DST transitions in Sydney that week, the meeting still happens at 9am local Sydney time (not at the original UTC moment). This is industry standard. **Needs confirmation from Oscar** if a different behaviour is wanted.

---

## Feature set

### Core converter (Free tier)
- Enter meeting time in any source timezone → see it in 1–7 of user's local zones
- Reverse lookup — type a time anywhere, see what it is locally
- Full IANA timezone database (every country, every city)
- Search-as-you-type timezone picker
- Live ticking world clocks for each zone
- DST detection per zone (small "DST" tag when active)
- UTC offset display (GMT+11 etc)
- Automatic date-rollover handling
- Meeting title + about/description fields
- Multi-zone result display simultaneously

### Personal zones
- Add up to 7 personal timezones
- One zone locked as "home" (visual anchor + offset reference)
- Add/remove anytime, search filter while adding
- Saves to Telegram CloudStorage per user (Mini App)
- Saves to browser localStorage (web)
- Persists across sessions, devices, reinstalls

### Scheduled meetings (Premium)
- Up to 7 personal + 7 per team
- Each meeting carries: title, description, source date+time, source timezone, attendees, created_by, status
- Live countdown (days / hours / minutes) on every card
- Past meetings auto-archive (7-slot count = upcoming only)
- "Updated 5m" badge for 24h after any change
- Sync on open + every 60s while open
- Tap to expand → full detail view (larger paired-time panel, full description, attendee list)
- Share/copy individual meeting as formatted text
- "Schedule with [member]" shortcut from Team Directory
- Owner can cancel meetings (soft-delete to archive, hard-delete is owner+confirm only)

### Team layer (Premium)
- Owner creates the workspace, names it
- Invite teammates by email
- Email link → join.php → joiner signs up / logs in → added to team
- Roles: Owner / Admin / Member
- Team Directory — every member's live local day/date/time/zone visible
- Each member sees team meetings converted to **their own** anchor zone
- Working-status dots on directory (green = working, grey = after hours, dark = asleep)
- Offset from viewer shown in plain English ("10 hrs behind", "same as you")
- Multiple teams per user supported
- Owner can transfer ownership (planned)
- Owner can remove members
- Members can leave team

### Sharing & output
- Copy meeting as plain text (formatted with both times + countdown)
- Copy single converted result (no meeting) as text
- Telegram native share — opens Telegram's share sheet pre-filled
- Toast feedback when copied ("Copied!")
- **Format example:**
  ```
  📅 Weekly check-in

  Meeting time:  Tuesday 20 May 2026 · 9:00 AM Sydney AEDT
  Your time:     Tuesday 20 May 2026 · 9:00 AM Hobart AEDT
  Countdown:     in 18h 23m

  — Sent from ClockTogether
  ```

### Telegram Mini App integration
- Opens full-screen inside Telegram
- Bot live: `@MeetingTimeConverterbot`
- Pinnable in unlimited Telegram groups
- Each user gets stateless session per open
- CloudStorage saves: zones, language, auth tokens
- Auto-detects Telegram user's language code on first open
- **Bot-edits-pinned-message** (planned next layer): owner posts meeting card to group via bot → bot pins it → when meeting time changes, bot edits the same pinned message → group always sees current time
- **Bot ↔ Team binding** — needs `/link <team-code>` command flow so a group knows which ClockTogether team it represents

### PWA — installable web app
- Install on iOS / Android home screen
- Offline support via service worker (sw.js)
- Custom app icon
- Splash screen
- Runs standalone (no browser chrome)
- `manifest.json` + `sw.js` files

### Languages & localisation
- Multi-language framework — English + Russian shipped
- Structure supports any language (more translations added as JSON dicts)
- Auto-detect from Telegram language code
- Auto-detect from browser language (fallback)
- Manual language switcher (override auto-detect)
- Date format localises (DD MMM YYYY vs MMM DD vs DD.MM.YYYY)
- Day names localise
- Timezone abbreviations localise where possible

---

## Backend architecture

### Database tables (MySQL)

| Table | Purpose | Key columns |
|---|---|---|
| `users` | Account records | id, email, password_hash, name, home_tz, language, email_verified, telegram_id, created_at |
| `user_zones` | Per-user personal timezones | id, user_id, tz, label, sort_order, is_home |
| `teams` | Team workspaces | id, name, owner_id, plan, created_at |
| `team_members` | Team membership + roles | team_id, user_id, role (owner/admin/member), joined_at |
| `meetings` | All scheduled meetings | id, team_id (nullable for personal), creator_id, title, description, source_tz, meeting_datetime (UTC), status, created_at, updated_at |
| `meeting_attendees` | Attendee responses | meeting_id, user_id, response (pending/accepted/declined) |
| `meeting_change_log` | Powers the "Updated" badge | meeting_id, changed_by, field_changed, old_value, new_value, changed_at |
| `invites` | Pending team invitations | id, team_id, email, invited_by, token, expires_at, accepted_at |
| `payments` | Stripe payment records | id, user_id, stripe_subscription_id, plan, status, current_period_end |
| `sessions` | Login sessions | id, user_id, token, expires_at, ip, user_agent |
| `password_resets` | Reset tokens | id, user_id, token, expires_at, used_at |
| `email_verifications` | Email verify tokens | id, user_id, token, expires_at, verified_at |
| `bot_groups` | Telegram groups bound to teams | id, telegram_chat_id, team_id, pinned_message_id, linked_by |

### Required indexes (for performance at scale)
- `users.email`, `users.telegram_id`
- `meetings.team_id + meeting_datetime`, `meetings.creator_id + status`
- `meeting_attendees.user_id`
- `team_members.user_id + team_id`
- `invites.token`, `password_resets.token`

### Server-side rules
- All writes validated server-side (never trust client)
- CSRF tokens on every POST
- Rate limiting on auth endpoints (5 failed logins → 15min lockout)
- httpOnly + secure cookies, 30-day expiry
- Sessions invalidated on password change

---

## Auth & accounts

### Signup paths
1. **Email signup** (web) — name, email, password → email verification link → account active
2. **Telegram Mini App** — auto-login via Telegram init data (no email required initially; required at first paid action)

### Flows built
- Sign up (signup.php)
- Login (login.php)
- Logout (logout.php)
- Forgot password (forgot.php + reset.php)
- Email verification (verify.php)
- Account dashboard (account.php) — manage plan, manage team, leave team, delete account, export data

### Telegram ↔ email account linking
- For v1: treat them as separate accounts
- "Link Telegram to email account" feature comes in v2
- Telegram-only users must add email before they can pay (Stripe requirement)

---

## Email system

### Emails sent (transactional only)

| # | Email | Trigger |
|---|---|---|
| 1 | Welcome + verify email | New signup |
| 2 | Password reset | Forgot password request |
| 3 | Team invitation | Owner invites teammate |
| 4 | Subscription confirmed | Stripe webhook on successful payment |
| 5 | Subscription cancelled | User cancels or renewal fails |
| 6 | Payment failed | Stripe retry failed |

**No** daily digests, meeting reminders, or marketing emails in v1.

### Resend setup — 5 steps to activate (Oscar's actions)
1. Resend dashboard → Domains → Add `clocktogether.com`
2. Resend gives 3-4 DNS records (SPF, DKIM, optionally DMARC)
3. GoDaddy DNS → paste records exactly as shown
4. Wait 10-30 mins → Resend shows "Verified"
5. Generate API key (`clocktogether-production`), sending-access only, paste into `config.php`

### Config block (config.php additions)
```php
define('RESEND_API_KEY', 're_xxxxxxxxxxxxxxxxxxxx');
define('FROM_EMAIL', 'noreply@clocktogether.com');
define('FROM_NAME', 'ClockTogether');
define('SUPPORT_EMAIL', 'support@clocktogether.com');
// SMTP fallback (Speed Reaper cPanel email)
define('SMTP_HOST', 'mail.clocktogether.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'noreply@clocktogether.com');
define('SMTP_PASS', '');
```

### Email files to build
- `classes/Mailer.php` — Resend API + SMTP fallback handler
- `emails/welcome.php`
- `emails/verify.php`
- `emails/reset.php`
- `emails/invite.php`
- `emails/sub-confirm.php`
- `emails/sub-cancel.php`
- `emails/payment-failed.php`
- `webhook-stripe.php` — handles Stripe events, triggers emails 4–6

Each template: branded HTML + plain text fallback, mobile-responsive, clocktogether.com header.

### Resend cost
Free tier: 3,000 emails/month, 100/day — covers ClockTogether comfortably for the first year.
Paid: $20/mo for 50,000 emails when needed.

---

## Stripe / monetisation

### Pricing (LOCKED)
- **Premium: $9 AUD / month**
- Annual discount %: TBD
- Free trial length: TBD (14 days suggested)
- Team size limit on Premium: TBD

### Free vs Premium feature split

| Feature | Free | Premium |
|---|---|---|
| Multi-zone converter | ✅ | ✅ |
| Reverse lookup | ✅ | ✅ |
| Up to 7 personal zones | ✅ | ✅ |
| 7 personal scheduled meetings | ✅ | ✅ |
| Telegram Mini App | ✅ | ✅ |
| PWA install | ✅ | ✅ |
| Create / join teams | ❌ | ✅ |
| Team Directory (live member times) | ❌ | ✅ |
| 7 team scheduled meetings | ❌ | ✅ |
| Multiple teams | ❌ | ✅ |
| Bot-edits-pinned-message | ❌ | ✅ |
| Calendar export (.ics) | ❌ | ✅ |
| GST/Tax handling | n/a | Auto via Stripe Tax |

### Stripe setup checklist
- Account on stripe.com/au
- ABN for Stripe Tax / GST (Oscar's ABN)
- Products created: Premium Monthly, Premium Annual
- Price IDs captured into config.php
- Webhook endpoint: `webhook-stripe.php` (signing secret in config)
- Customer portal enabled (for self-serve subscription management)

---

## Telegram bot integration

### @MeetingTimeConverterbot
- Already created in BotFather
- Currently points to old `e25c.com/tools/meeting-converter.html`
- **Update needed:** BotFather → set Web App URL to `https://clocktogether.com/app.php` (or `index.php` depending on deploy structure)

### Bot-edits-pin feature (Premium team)
- Team owner uses `/postmeeting <id>` in a linked Telegram group
- Bot posts the meeting card as its own message
- Bot pins that message
- When the meeting time/title changes in the app, bot edits the same pinned message
- Group always sees current state without manual updates

### Required bot commands
- `/start` — welcome message + link to open Mini App
- `/link <team-code>` — binds this Telegram group to a ClockTogether team (owner generates code in app)
- `/postmeeting <meeting-id>` — bot posts the meeting card to this group
- `/help` — list commands

### ad-config.json (bot owner monetisation slot)
- Optional file on Speed Reaper at `/ad-config.json`
- App fetches it on load
- Renders sponsor slot at bottom of app
- Supports: image URL, GIF URL, text + link, or empty (slot invisible)
- Edit once → updates everywhere

```json
{
  "enabled": true,
  "type": "image",
  "image_url": "https://clocktogether.com/sponsors/example.png",
  "link": "https://example.com",
  "label": "Sponsored"
}
```

---

## File manifest — full build

### Pages
- `index.php` — Landing page (sales/marketing)
- `app.php` — The app shell (auth-gated, loads tabs)
- `signup.php` / `login.php` / `logout.php` / `forgot.php` / `reset.php` / `verify.php`
- `account.php` — Subscription + team management
- `join.php` — Team invitation acceptance
- `checkout.php` — Stripe checkout redirect
- `webhook-stripe.php` — Stripe event handler

### Includes / classes
- `config.php` — All API keys, DB credentials, constants
- `db.php` — Database connection (PDO)
- `auth.php` — Session helper, login gate
- `classes/User.php`, `classes/Team.php`, `classes/Meeting.php`, `classes/Mailer.php`, `classes/Stripe.php`, `classes/TelegramBot.php`

### App tabs (loaded via app.php)
- `tabs/zones.php` — Personal zones tab
- `tabs/convert.php` — Converter tab
- `tabs/meetings.php` — Scheduled meetings tab
- `tabs/team.php` — Team directory tab (Premium)

### Migrations
- `migrate.sql` — Creates all tables, indexes, default data

### PWA
- `manifest.json`
- `sw.js`
- `icon.png` + various sizes

### Email templates
- `emails/welcome.php`, `verify.php`, `reset.php`, `invite.php`, `sub-confirm.php`, `sub-cancel.php`, `payment-failed.php`

### Telegram bot endpoints
- `bot/webhook.php` — Telegram webhook receiver
- `bot/commands.php` — Command dispatcher
- `bot/post-meeting.php` — Posts and edits group messages

### Cron jobs (4)
- Daily — archive past meetings
- Daily — clean expired invites + reset tokens
- Hourly — Stripe subscription status sync
- Every 5 min — bot pinned-message refresh check

### Static assets
- `/assets/css/app.css`
- `/assets/js/app.js`
- `/assets/js/meetings.js` (meetings tab logic)
- `/assets/js/team.js` (team directory ticker)
- `/assets/img/icon.png`

### Other
- `DEPLOY.md` — Step-by-step Speed Reaper deployment guide
- `.htaccess` — clean URLs, HTTPS enforcement, security headers
- `robots.txt`, `sitemap.xml`

**Total file count:** ~40 files

---

## Deployment plan (Speed Reaper)

1. Speed Reaper cPanel → File Manager → upload all files to `public_html/`
2. Create MySQL database in cPanel → run `migrate.sql`
3. Fill `config.php` with all keys/credentials
4. Set up 4 cron jobs in cPanel
5. Verify Resend domain (DNS records on GoDaddy)
6. Verify Stripe webhook endpoint pointing to `webhook-stripe.php`
7. Update BotFather Web App URL to clocktogether.com
8. Test full flow — signup → verify → create team → invite member → schedule meeting → owner edits time → member sees update
9. Pin Telegram bot in test group, post a meeting, confirm bot edits work
10. Go live

---

## AUDIT — Critical decisions pending (7 remaining)

1. **Premium price?** ~~($/mo AUD, annual discount %, free trial length)~~ ✅ **LOCKED: $9 AUD/month** (annual %, trial length still TBD)
2. **Email verification mandatory before app usage, or only before paying?**
3. **Owner cancels Premium → team meetings: lock read-only / archive / delete after 30 days?**
4. **Telegram-only users → require email at first paid action, or block payment entirely?**
5. **Team size limit on Premium?** Unlimited / 25 / 100
6. **DST behaviour — lock-clock-time (default) or lock-UTC?** Default = "9am means 9am no matter what DST does"
7. **Do you have an ABN to enable Stripe Tax for GST?**
8. **Free trial required at signup, or upgrade-anytime?**

---

## AUDIT — Important gaps (ship with v1)

| # | Item | Notes |
|---|---|---|
| 1 | Empty states UI | Meetings tab with zero meetings, Team tab before invites |
| 2 | Account deletion | GDPR — cascade delete meetings, leave teams, kill sessions |
| 3 | Data export (JSON) | GDPR requirement |
| 4 | Owner transfer | Hand team to someone else, owner leaves company |
| 5 | Calendar export (.ics) | One-click add to Google/Apple/Outlook |
| 6 | Meeting cancellation | Soft-delete vs hard-delete UX |
| 7 | Edit detection logic | Title edits = no "Updated" badge; time edits = yes |
| 8 | Brute-force protection | 5 failed login attempts → 15min lockout |
| 9 | CSRF tokens + rate limiting | All POST endpoints |
| 10 | Captcha on signup | Cloudflare Turnstile (free) — stops bot signups |
| 11 | Support email + contact form | Stripe + app stores require it |
| 12 | Forgot password expiry | 1hr expiry, single-use tokens |
| 13 | Session security | httpOnly + secure cookies, force logout on password change |
| 14 | Database backup | Daily Speed Reaper backup, kept 30 days |
| 15 | Maximum advance booking | Cap at 1 year out |
| 16 | Privacy Policy + Terms of Service | Stripe blocks payments without these |

---

## AUDIT — Deferrable (v2)

| # | Item |
|---|---|
| 1 | Recurring meetings (weekly standup) |
| 2 | Push notifications via PWA |
| 3 | Attendee accept/decline UI (schema already supports it) |
| 4 | Admin dashboard (use phpMyAdmin until needed) |
| 5 | 2FA on accounts |
| 6 | Analytics (Plausible / Fathom) |
| 7 | Telegram ↔ email account linking |
| 8 | In-app reminders / notifications |
| 9 | Multi-currency Stripe (launch AUD only) |
| 10 | Marketing email opt-in |

---

## UI mockups — design references

Two mockups built so far (rendered in chat, can be regenerated any time):

1. **Meetings tab** — Team meetings section (3/7) + personal section (2/7), each card showing dual-time panel with day + date + time + zone for both source and local, countdown footer, "Updated 5m" badge, owner-only locked button on team section
2. **Team directory tab** — "You" anchor card with green border, 4 member cards below sorted by offset, each showing avatar+initials, name+role, home zone, current day/date/time, offset description ("10 hrs behind"), working-status dot (green/grey/dark)

Both saved as separate HTML files alongside this spec.

---

## Next steps — action sequence

### Oscar's actions (before build starts)
1. Answer the 8 critical decisions (section above)
2. Set up Resend domain verification for clocktogether.com (5 steps in Email section)
3. Create Stripe products + capture price IDs
4. Confirm ABN for Stripe Tax (or note that GST is handled elsewhere)
5. Provide DataForSEO credentials (if any cross-product needs)

### Claude's actions (once decisions in)
1. Lock pricing into config block
2. Build all ~40 files end-to-end
3. Output as ZIP for Speed Reaper upload
4. Provide step-by-step deploy guide
5. Provide test checklist

### Post-launch (week 1)
- Monitor Resend deliverability
- Monitor Stripe webhook delivery
- Test Telegram bot flow in real group
- First user signups

### Post-launch (month 1)
- Add Calendar export (.ics) if usage warrants
- Add recurring meetings if requested
- Review audit "important" gaps not built in v1

---

## Brand voice / copy guidelines

- Tone: direct, practical, slightly playful but never gimmicky
- Australian English spelling (organise, colour, behaviour)
- Plain language — no jargon
- The product name "ClockTogether" — always one word, both caps
- Sub-brand "Meetings", "Team", "Zones", "Convert" — sentence case

---

## Open questions parking lot

Add new questions here as they come up. Not blockers, but worth resolving:

- Should the bot have a "/converttime" inline command that any group member can use (not just the binder)?
- Should the team's name and logo be customisable, or just the name?
- Custom domain support for Premium teams (e.g. `mtfburnie.clocktogether.com`)?
- Should "Updated" badge persist longer than 24h if no one in the team has opened the app?

---

*End of spec. This document is the source of truth. If any prior conversation contradicts what's here, this document wins.*
