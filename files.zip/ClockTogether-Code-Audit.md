# ClockTogether — Code Audit Report

**Date:** 20 May 2026
**Files audited:** `index.html`, `app.js`, `cities.js`, `DEPLOY.md`, master spec, mockups
**Status:** Audit complete, all critical fixes applied

---

## Summary

Audited the full ClockTogether codebase against 6 categories: functional correctness, dead code, duplicate code, security, code quality, and documentation freshness. Found **1 functional bug**, **7 cleanup opportunities**, and confirmed everything else is in good shape. All issues fixed in place.

---

## Findings & fixes

### 1. 🐛 FUNCTIONAL BUG — Double interval on map tick (FIXED)

**File:** `app.js` lines 287-292 (before fix)

**The bug:** Two `setInterval(tickMap, 60_000)` calls were created — one immediately at script load, another inside the `setTimeout` that aligns to the next minute boundary. After the first minute elapsed, the map was redrawing **twice per minute** instead of once, with the second call drifting further off-clock over time.

**Impact:** Wasted CPU/redraws (~2x map work). City clocks could appear to "stutter" near minute boundaries. Battery drain on mobile.

**Fix:** Removed the immediate interval. Kept only the timeout that fires on the next minute boundary and then starts a single interval.

```js
// Before
setInterval(tickMap, 60_000);
const msToNextMin = 60_000 - (Date.now() % 60_000);
setTimeout(() => { tickMap(); setInterval(tickMap, 60_000); }, msToNextMin);

// After
const msToNextMin = 60_000 - (Date.now() % 60_000);
setTimeout(() => {
  tickMap();
  setInterval(tickMap, 60_000);
}, msToNextMin);
```

---

### 2. 💀 Dead variable `utc` in `subsolarPoint` (FIXED)

**File:** `app.js` line 112 (before fix)

A `const utc = ...` line was computed but never referenced anywhere in the function or elsewhere. Pure dead code, likely a leftover from an earlier iteration.

**Fix:** Removed the variable.

---

### 3. 💀 Unused parameter `date` in `subsolarPoint` (FIXED)

**File:** `app.js` line 109 (before fix)

Function signature accepted an optional `date` parameter, but no caller ever passed one. The internal logic always fell through to `new Date()`.

**Fix:** Simplified to `function subsolarPoint()` with no arguments.

---

### 4. 🔓 Inline `onclick` handler (FIXED)

**File:** `app.js` — in the `renderResult` template string

The Copy button was wired with `onclick="copyResult()"` inline, which:
- Required `window.copyResult` to be globally exposed
- Mixed presentation (HTML markup) with behaviour (event handler)
- Made CSP (Content Security Policy) hardening harder later
- Was inconsistent with the rest of the codebase that uses `addEventListener`

**Fix:** Changed the button to use an `id` and wired it via `addEventListener` after the HTML is inserted. Demoted `window.copyResult` to a plain function (no longer global).

```js
// Before
<button class="copy-btn" onclick="copyResult()">Copy ↗</button>
// + window.copyResult = function () { ... };

// After
<button class="copy-btn" id="result-copy-btn">Copy ↗</button>
// + document.getElementById('result-copy-btn').addEventListener('click', copyResult);
// + function copyResult() { ... }
```

---

### 5. ♻️ Repeated sun marker code (FIXED)

**File:** `app.js` — in `drawDayNight()`

Three nearly-identical `.append("circle")` blocks built the sun's layered glow effect, with only radius/fill/opacity differing. Each block was 4 lines, so 12 lines of essentially-duplicate code.

**Fix:** Collapsed to a single `sunLayers` config array iterated with `.forEach()`. More maintainable — adding/removing a glow layer now needs only one line change.

```js
const sunLayers = [
  { r: 22, fill: "#FFD56B", opacity: 0.25, glow: true },
  { r: 14, fill: "#FFD56B", opacity: 0.6,  glow: true },
  { r:  7, fill: "#FFE9A8", opacity: 1,    glow: false }
];
sunLayers.forEach(L => { /* ... append circle ... */ });
```

---

### 6. 🎨 Dead CSS variables (FIXED)

**File:** `index.html` — `:root` block

Three CSS custom properties were defined but never referenced anywhere in stylesheet or markup:
- `--teal-glow: rgba(29, 158, 117, 0.25)` — leftover from an earlier glow effect that ended up using inline values
- `--map-mid: #0F3D2E` — only used in JS inline (`d3.append("rect").attr("fill"...)`), not via CSS var
- `--map-land: #2A5A45` — same as above

**Fix:** Removed all three from the `:root` block. Saved ~150 bytes; cleaner palette declaration.

---

### 7. ℹ️ Unused `.sr-only` class (LEFT IN PLACE)

**File:** `index.html`

The accessibility helper class `.sr-only` is declared but no element uses it. The class itself is only 5 lines and is a useful pattern for screen-reader-only labels. Kept in place — likely to be used in Phase 2 (form labels, etc.) and removing-then-re-adding is wasted churn.

---

## Categories where the code already passed

- ✅ **No SQL injection vectors** (no database calls yet, but no string concatenation in JS that touches user input either)
- ✅ **No `eval()`, `new Function()`, or dynamic code execution**
- ✅ **No timing-attack vulnerabilities** (no auth comparisons)
- ✅ **No exposed secrets, API keys, or credentials in source**
- ✅ **`cities.js` is duplicate-free** — 58 unique cities, no name collisions, all IANA timezone strings are valid
- ✅ **HTML structure is semantic** — proper `<header>`, `<section>`, `<footer>`, `<nav>` usage
- ✅ **No broken cross-references** between HTML IDs and JS lookups
- ✅ **No stale `$TBD` or "pending" references** in deployable files (the spec markdown still has open audit items, which is intentional)
- ✅ **CSS variable scheme is consistent** — every brand colour goes through `--teal*`, `--ink*`, `--cream*`, etc.
- ✅ **Single source of truth for cities** — `window.CITIES` array, no shadowing or alternative copies
- ✅ **All CSS classes used in JS-rendered HTML are defined in the stylesheet** (verified via static analysis)

---

## File size impact

| File | Before | After | Change |
|---|---|---|---|
| `index.html` | 31,329 bytes | 30,952 bytes | -377 bytes (-1.2%) |
| `app.js` | 17,047 bytes | 17,056 bytes | +9 bytes (negligible — cleaner refactor is slightly more verbose but readable) |
| `cities.js` | 6,940 bytes | 6,940 bytes | unchanged |

**Net result:** ~370 bytes smaller, no functionality changes, one real bug fixed, six maintainability improvements.

---

## What was NOT done (deliberately deferred)

These are minor opportunities that aren't worth the churn right now:

1. **DOM lookup caching** — calling `document.getElementById('conv-from')` multiple times is not a perf issue on a landing page. Adding a `DOM = {}` cache would be premature optimisation for code that runs at user-click speed
2. **Magic number extraction** — values like `60_000`, `86400000`, `3600000` are easily understood inline. Extracting to `const MS_PER_MINUTE = 60_000` etc. would add lines without meaningful clarity
3. **TypeScript / JSDoc type annotations** — the codebase is small enough that types would slow iteration. Reconsider for Phase 2 if it grows past ~2000 lines
4. **Splitting `app.js` into modules** — currently 484 lines, all related. Premature to split for a single landing page
5. **CSS-in-JS or extracting `<style>` to external `landing.css`** — same file is easier to deploy (one upload). Split later if needed for cacheability

---

## Remaining open items (not code — process)

1. **8 critical product decisions** — see master spec audit section. Pricing is now locked at $9 AUD, 7 remain
2. **Trademark filing** — "ClockTogether" in IP Australia class 42
3. **Real testimonials** — placeholders need replacement after launch
4. **Phase 2 build** — auth, Stripe, teams, meetings, Telegram Mini App, email
5. **Bot URL update** — BotFather still points `@MeetingTimeConverterbot` at the old `e25c.com` URL

---

## Final read

The codebase is in good shape. One real functional bug (the double interval) is fixed. Six code-quality and dead-code items cleaned up. No security issues found. Documentation is current.

Total time-to-deploy for the landing page: **~30 minutes of upload + DNS + verification work**, no code changes needed.

The remaining blockers are product decisions and Phase 2 build work — not code quality issues.
