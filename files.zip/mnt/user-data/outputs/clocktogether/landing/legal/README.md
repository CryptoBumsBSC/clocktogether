# Legal pages — deployment guide

Two ready-to-deploy HTML pages plus the production `.htaccess` for Speed Reaper.

## Files

| File | Where it goes on Speed Reaper | What it does |
|---|---|---|
| `.htaccess` | `public_html/.htaccess` | HTTPS enforcement, security headers, gzip, caching, hidden-file protection |
| `legal/privacy.html` | `public_html/privacy.html` | Privacy Policy at `https://clocktogether.com/privacy.html` |
| `legal/terms.html` | `public_html/terms.html` | Terms of Service at `https://clocktogether.com/terms.html` |

The landing page footer already links to `/privacy.html` and `/terms.html`, so once the files are uploaded, the links work automatically.

## Required edits before going live

Both legal pages contain placeholders marked with `[BRACKETS]` and `Review` flags. Fill these in before activating Stripe live payments:

| Placeholder | What to fill in |
|---|---|
| `[REGISTERED BUSINESS NAME]` | Your registered business / sole trader name (the one on your ABN) |
| `[ABN]` | Your Australian Business Number |
| `[REGISTERED BUSINESS ADDRESS]` | Your registered postal address in Tasmania |
| `[HOSTING REGION]` | The country where Speed Reaper actually hosts the servers (US? AU? Check with Speed Reaper support) |
| `[email protected]` / `[email protected]` / `[email protected]` | Real mailbox addresses — create them in cPanel first |

Search both files for `[` and `Review` to find all of these.

## Lawyer review checklist

Before turning on paid subscriptions in Stripe, get a 30-minute lawyer review (~$200-400 AUD) and ask them to specifically check:

### Privacy Policy
- [ ] Australian Privacy Principles compliance for your specific business structure
- [ ] GDPR Article 13/14 requirements (information to be provided)
- [ ] Notifiable Data Breaches scheme alignment
- [ ] International data transfer language (especially Stripe routing through US/Ireland)
- [ ] Data retention periods match your actual backup and deletion practices

### Terms of Service
- [ ] Australian Consumer Law guarantees not unlawfully excluded
- [ ] Refund policy compliant with ACL and Stripe's requirements
- [ ] Liability cap is enforceable (the $100/12-months wording)
- [ ] Dispute resolution clause is enforceable in Tasmania
- [ ] Team-data-after-cancellation policy matches your actual implementation
- [ ] Free trial language matches what you actually offer (or remove if no trial)

## .htaccess specifics

The `.htaccess` is configured for the current Phase 1 setup. Two adjustments needed once Phase 2 is built:

### When you add Stripe
Find the `Content-Security-Policy` line and add Stripe domains:

```apache
# Current Phase 1:
Header always set Content-Security-Policy "... script-src 'self' https://cdn.jsdelivr.net; ..."

# Phase 2 with Stripe:
Header always set Content-Security-Policy "... script-src 'self' https://cdn.jsdelivr.net https://js.stripe.com; ... frame-src https://js.stripe.com https://hooks.stripe.com; ..."
```

### When you add a 404 page
Uncomment these lines near the bottom:

```apache
# ErrorDocument 404 /404.html
# ErrorDocument 500 /500.html
```

## Testing after deployment

Once `.htaccess` is uploaded, verify the security headers are firing:

1. **SSL test** — https://www.ssllabs.com/ssltest/analyze.html?d=clocktogether.com → aim for A or A+
2. **Security headers** — https://securityheaders.com/?q=clocktogether.com → aim for A
3. **HSTS preload eligibility check** — https://hstspreload.org/?domain=clocktogether.com → submit once you're confident

If anything throws a 500 error, comment out the `Content-Security-Policy` line first — it's the most likely culprit, and the rest of the file still works without it.

## Why these files matter

- **Stripe requires** an accessible privacy policy and terms of service to activate live payment processing. They check both URLs during onboarding.
- **Australian Privacy Act** requires a Privacy Policy if you handle personal information for business purposes.
- **GDPR** requires explicit information about how EU/UK users' data is processed.
- **`.htaccess` security headers** prevent ~80% of common web attacks (clickjacking, MIME sniffing, mixed content, etc.) for the cost of one upload.

Together with the audited landing page, this is everything you need on the legal/security side to switch the site from a public demo to a payments-ready product.
