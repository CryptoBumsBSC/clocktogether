# ClockTogether

> A multi-timezone meeting scheduler for global teams. Mobile-first, Telegram-native, AU-priced at $9 AUD/month.

**Status:** Phase 1 complete and deploy-ready. Phase 2 (auth, payments, team features) pending 7 product decisions.
**Domain:** clocktogether.com
**Hosting:** Speed Reaper (PHP/MySQL)
**Total package:** 14 files, ~232 KB
**Last updated:** 20 May 2026

---

## Quick start

```bash
# Test locally first
cd landing/
python3 -m http.server 8000
# Open http://localhost:8000

# Then deploy to Speed Reaper
# 1. cPanel → File Manager → public_html
# 2. Upload everything inside landing/ (including .htaccess and legal/)
# 3. Visit https://clocktogether.com
```

Detailed deployment instructions: `landing/DEPLOY.md`
Legal-pages setup: `landing/legal/README.md`

---

## Complete project structure

```
clocktogether/
│
├── README.md                                ← you are here
│
├── landing/                                 ← DEPLOY THIS FOLDER to public_html/
│   ├── .htaccess                            HTTPS, security headers, gzip, caching
│   ├── index.html                           Full landing page (single file)
│   ├── app.js                               Map + day/night + converter logic
│   ├── cities.js                            58-city database with IANA timezones
│   ├── DEPLOY.md                            Step-by-step Speed Reaper instructions
│   └── legal/
│       ├── README.md                        Legal-pages deployment guide
│       ├── privacy.html                     Privacy Policy (AU + GDPR template)
│       └── terms.html                       Terms of Service (AU jurisdiction)
│
├── docs/                                    ← REFERENCE — source of truth
│   ├── ClockTogether-Master-Spec.md         Full product spec, locked rules, decisions
│   ├── ClockTogether-Competitive-Analysis.md  Market research, positioning, threats
│   └── ClockTogether-Code-Audit.md          Code quality audit + cleanup record
│
└── mockups/                                 ← DESIGN REFERENCES for Phase 2
    ├── mockup-meetings-tab.html             Scheduled meetings UI (open in browser)
    └── mockup-team-directory.html           Team Directory UI with live member times
```

---

## What's deploy-ready right now

The full `landing/` folder is production-grade and ready to upload to Speed Reaper:

- **Landing page** with real working world map (D3 + world-atlas), live day/night terminator, 21 clickable city markers, free converter, copy-to-clipboard, day-rollover warning
- **`.htaccess`** with HTTPS enforcement, security headers (HSTS, CSP, X-Frame-Options, Referrer-Policy, Permissions-Policy), gzip compression, sensible cache lifetimes, attack-pattern blocking
- **Privacy Policy** — 13 sections covering APP + GDPR + UK GDPR, AU jurisdiction
- **Terms of Service** — 19 sections, $9 AUD subscription terms, AU consumer law preserved, Tasmania governing law

---

## Required edits before going live

Both legal pages contain placeholders marked `[BRACKETS]` and `Review` flags. Search for them and fill in:

| Placeholder | What to fill in |
|---|---|
| `[REGISTERED BUSINESS NAME]` | Your trading name on the ABN |
| `[ABN]` | Your Australian Business Number |
| `[REGISTERED BUSINESS ADDRESS]` | Your registered postal address |
| `[HOSTING REGION]` | Where Speed Reaper actually hosts (ask their support) |
| `[email protected]` / `[email protected]` / `[email protected]` | Mailboxes — create in cPanel first |

Full pre-launch checklist: `landing/legal/README.md`

---

## Locked decisions

- ✅ **Premium price:** $9 AUD / month
- ✅ **Domain:** clocktogether.com
- ✅ **Hosting:** Speed Reaper (PHP/MySQL)
- ✅ **Brand colour:** #1D9E75 (teal)
- ✅ **Telegram bot:** `@MeetingTimeConverterbot`
- ✅ **Typography:** Instrument Serif + DM Sans + JetBrains Mono
- ✅ **Governing law:** Tasmania, Australia

### Design rules (apply globally — see Master Spec)

1. Dual-time display — source time + your time, equal visual weight, always
2. Full format — day + date + time + timezone, everywhere
3. 7-meeting limit — 7 personal per user + 7 per team they belong to
4. Team meetings: owner/admin only — members view, owners control
5. In-app sync only — no email/push notifications on meeting changes
6. Auto-archive past meetings — 7-slot count is upcoming only
7. DST: lock-clock-time (pending final confirmation)

---

## 7 critical decisions still open

These block Phase 2 build:

1. ☐ **Email verification** — required before any app use, or only before paying?
2. ☐ **Owner cancels Premium** — what happens to team meetings? (lock / archive / delete)
3. ☐ **Telegram-only users without email** — how do they pay?
4. ☐ **Team size limit on Premium** — unlimited / 25 / 100?
5. ☐ **DST behaviour** — lock-clock-time (default) or lock-UTC?
6. ☐ **ABN for Stripe Tax** — number needed for AU GST handling
7. ☐ **Free trial timing** — required at signup, or upgrade-anytime?

---

## What's NOT built (Phase 2)

- Signup / login / account dashboard
- MySQL database (schema written, not migrated)
- Stripe checkout + webhook + subscription management
- Personal scheduled meetings (UI mocked, no code)
- Team creation + invitation flow
- Team Directory tab (UI mocked, no code)
- Telegram Mini App integration
- Bot commands + bot-edits-pinned-message
- PWA manifest + service worker
- Email templates (Resend integration)
- Multi-language framework (English + Russian planned)
- robots.txt + sitemap.xml + analytics

Estimated build: **~22 sessions** per `docs/ClockTogether-Master-Spec.md`

---

## Reading order for new sessions

1. **This README** (10 min) — overview, structure, current state
2. **`docs/ClockTogether-Master-Spec.md`** (30 min) — full spec, every feature, every locked rule
3. **`docs/ClockTogether-Competitive-Analysis.md`** (20 min) — market positioning
4. **`landing/DEPLOY.md`** (5 min) — deployment + customisation reference
5. **`landing/legal/README.md`** (5 min) — legal pages deployment guide
6. **`landing/index.html` + `app.js` + `cities.js`** (60 min) — the actual code
7. **`docs/ClockTogether-Code-Audit.md`** (10 min) — what was cleaned and why
8. **`mockups/*.html`** (open in browser, 5 min each) — Phase 2 design references

---

## Recommended next steps

### This week (1-2 hours of your time)
1. **Lock the 7 product decisions** — unblocks all of Phase 2
2. **Fill the legal-page placeholders** with your real ABN + business name + address
3. **Get a 1-hour lawyer review** of the privacy + terms pages (~$200-400 AUD)
4. **Set up `support@`, `legal@`, `privacy@`** mailboxes in cPanel
5. **Deploy `landing/` to Speed Reaper** — live at clocktogether.com
6. **Update BotFather** — point `@MeetingTimeConverterbot` Web App URL to clocktogether.com
7. **Add Plausible analytics** — single script tag, privacy-friendly

### Then (Phase 2 — ~22 build sessions)
- Session 1: MySQL schema + migrations
- Sessions 2-3: Auth (signup, login, password reset, sessions)
- Session 4: Account dashboard
- Session 5: Personal zones management
- Sessions 6-7: Personal scheduled meetings (CRUD + UI)
- Session 8: Team creation + invitation
- Session 9: Team Directory (working version)
- Sessions 10-11: Team meetings (CRUD + sync)
- Session 12: Stripe integration + webhook
- Session 13: Email templates + Resend
- Session 14: Telegram Mini App wiring
- Session 15-16: Bot commands + bot-edits-pin
- Session 17: PWA (manifest + SW + icons)
- Session 18: Multi-language framework
- Session 19: robots.txt + sitemap + analytics
- Sessions 20-22: Testing + bug fixes + polish

---

## Contact / handover

**Project owner:** Oscar James (AussieBoomer)
**Location:** Burnie, North West Tasmania, Australia
**Stack:** Same as Yakkafy (PHP/MySQL on Speed Reaper, Stripe AU, Resend)

Designed and built across multiple Claude sessions, May 2026. Every decision is documented in `docs/ClockTogether-Master-Spec.md` — that's the source of truth. If a chat conversation contradicts the spec, the spec wins.

---

*The market is open. The differentiation is real. Execute Phase 2 and ship.*
