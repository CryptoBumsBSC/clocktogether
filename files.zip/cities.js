/**
 * ClockTogether — Curated city database
 *
 * The cities map markers, the converter dropdown, and timezone math all read from here.
 * Adding a city: append to CITIES with the schema below. To make it visible on the map
 * by default, also append the name to FEATURED_CITIES.
 *
 * @typedef {Object} City
 * @property {string} name     Human-readable display name (e.g. "São Paulo")
 * @property {string} country  Country or region name (e.g. "Brazil")
 * @property {string} tz       Valid IANA timezone identifier (e.g. "America/Sao_Paulo")
 * @property {number} lat      Latitude in decimal degrees (-90 to 90)
 * @property {number} lng      Longitude in decimal degrees (-180 to 180)
 */

/** @type {ReadonlyArray<City>} */
window.CITIES = Object.freeze([
  // ---- North America ----
  { name: 'Los Angeles',  country: 'USA',         tz: 'America/Los_Angeles',  lat:  34.05, lng: -118.24 },
  { name: 'Denver',       country: 'USA',         tz: 'America/Denver',       lat:  39.74, lng: -104.99 },
  { name: 'Chicago',      country: 'USA',         tz: 'America/Chicago',      lat:  41.88, lng:  -87.63 },
  { name: 'New York',     country: 'USA',         tz: 'America/New_York',     lat:  40.71, lng:  -74.01 },
  { name: 'Toronto',      country: 'Canada',      tz: 'America/Toronto',      lat:  43.65, lng:  -79.38 },
  { name: 'Vancouver',    country: 'Canada',      tz: 'America/Vancouver',    lat:  49.28, lng: -123.12 },
  { name: 'Mexico City',  country: 'Mexico',      tz: 'America/Mexico_City',  lat:  19.43, lng:  -99.13 },

  // ---- South America ----
  { name: 'Bogotá',       country: 'Colombia',    tz: 'America/Bogota',                  lat:   4.71, lng: -74.07 },
  { name: 'Lima',         country: 'Peru',        tz: 'America/Lima',                    lat: -12.05, lng: -77.04 },
  { name: 'São Paulo',    country: 'Brazil',      tz: 'America/Sao_Paulo',               lat: -23.55, lng: -46.63 },
  { name: 'Buenos Aires', country: 'Argentina',   tz: 'America/Argentina/Buenos_Aires',  lat: -34.61, lng: -58.38 },
  { name: 'Santiago',     country: 'Chile',       tz: 'America/Santiago',                lat: -33.45, lng: -70.67 },

  // ---- Europe ----
  { name: 'London',       country: 'UK',          tz: 'Europe/London',        lat: 51.51, lng:  -0.13 },
  { name: 'Dublin',       country: 'Ireland',     tz: 'Europe/Dublin',        lat: 53.35, lng:  -6.26 },
  { name: 'Lisbon',       country: 'Portugal',    tz: 'Europe/Lisbon',        lat: 38.72, lng:  -9.14 },
  { name: 'Madrid',       country: 'Spain',       tz: 'Europe/Madrid',        lat: 40.42, lng:  -3.70 },
  { name: 'Paris',        country: 'France',      tz: 'Europe/Paris',         lat: 48.86, lng:   2.35 },
  { name: 'Amsterdam',    country: 'Netherlands', tz: 'Europe/Amsterdam',     lat: 52.37, lng:   4.90 },
  { name: 'Berlin',       country: 'Germany',     tz: 'Europe/Berlin',        lat: 52.52, lng:  13.41 },
  { name: 'Rome',         country: 'Italy',       tz: 'Europe/Rome',          lat: 41.90, lng:  12.50 },
  { name: 'Zurich',       country: 'Switzerland', tz: 'Europe/Zurich',        lat: 47.38, lng:   8.55 },
  { name: 'Stockholm',    country: 'Sweden',      tz: 'Europe/Stockholm',     lat: 59.33, lng:  18.07 },
  { name: 'Athens',       country: 'Greece',      tz: 'Europe/Athens',        lat: 37.98, lng:  23.73 },
  { name: 'Helsinki',     country: 'Finland',     tz: 'Europe/Helsinki',      lat: 60.17, lng:  24.94 },
  { name: 'Warsaw',       country: 'Poland',      tz: 'Europe/Warsaw',        lat: 52.23, lng:  21.01 },
  { name: 'Moscow',       country: 'Russia',      tz: 'Europe/Moscow',        lat: 55.76, lng:  37.62 },

  // ---- Africa ----
  { name: 'Lagos',        country: 'Nigeria',     tz: 'Africa/Lagos',         lat:   6.52, lng:   3.38 },
  { name: 'Cairo',        country: 'Egypt',       tz: 'Africa/Cairo',         lat:  30.04, lng:  31.24 },
  { name: 'Nairobi',      country: 'Kenya',       tz: 'Africa/Nairobi',       lat:  -1.29, lng:  36.82 },
  { name: 'Johannesburg', country: 'S. Africa',   tz: 'Africa/Johannesburg',  lat: -26.20, lng:  28.05 },

  // ---- Middle East ----
  { name: 'Istanbul',     country: 'Turkey',      tz: 'Europe/Istanbul',      lat: 41.01, lng:  28.98 },
  { name: 'Tel Aviv',     country: 'Israel',      tz: 'Asia/Jerusalem',       lat: 32.08, lng:  34.78 },
  { name: 'Riyadh',       country: 'Saudi Arabia',tz: 'Asia/Riyadh',          lat: 24.71, lng:  46.68 },
  { name: 'Dubai',        country: 'UAE',         tz: 'Asia/Dubai',           lat: 25.20, lng:  55.27 },
  { name: 'Tehran',       country: 'Iran',        tz: 'Asia/Tehran',          lat: 35.69, lng:  51.39 },

  // ---- Asia ----
  { name: 'Karachi',      country: 'Pakistan',    tz: 'Asia/Karachi',         lat: 24.86, lng:  67.01 },
  { name: 'Mumbai',       country: 'India',       tz: 'Asia/Kolkata',         lat: 19.08, lng:  72.88 },
  { name: 'Delhi',        country: 'India',       tz: 'Asia/Kolkata',         lat: 28.61, lng:  77.21 },
  { name: 'Dhaka',        country: 'Bangladesh',  tz: 'Asia/Dhaka',           lat: 23.81, lng:  90.41 },
  { name: 'Bangkok',      country: 'Thailand',    tz: 'Asia/Bangkok',         lat: 13.76, lng: 100.50 },
  { name: 'Jakarta',      country: 'Indonesia',   tz: 'Asia/Jakarta',         lat: -6.21, lng: 106.85 },
  { name: 'Singapore',    country: 'Singapore',   tz: 'Asia/Singapore',       lat:  1.35, lng: 103.82 },
  { name: 'Kuala Lumpur', country: 'Malaysia',    tz: 'Asia/Kuala_Lumpur',    lat:  3.14, lng: 101.69 },
  { name: 'Manila',       country: 'Philippines', tz: 'Asia/Manila',          lat: 14.60, lng: 120.98 },
  { name: 'Hong Kong',    country: 'Hong Kong',   tz: 'Asia/Hong_Kong',       lat: 22.32, lng: 114.17 },
  { name: 'Shanghai',     country: 'China',       tz: 'Asia/Shanghai',        lat: 31.23, lng: 121.47 },
  { name: 'Beijing',      country: 'China',       tz: 'Asia/Shanghai',        lat: 39.90, lng: 116.41 },
  { name: 'Seoul',        country: 'S. Korea',    tz: 'Asia/Seoul',           lat: 37.57, lng: 126.98 },
  { name: 'Tokyo',        country: 'Japan',       tz: 'Asia/Tokyo',           lat: 35.68, lng: 139.69 },

  // ---- Oceania ----
  { name: 'Perth',        country: 'Australia',   tz: 'Australia/Perth',      lat: -31.95, lng: 115.86 },
  { name: 'Adelaide',     country: 'Australia',   tz: 'Australia/Adelaide',   lat: -34.93, lng: 138.60 },
  { name: 'Brisbane',     country: 'Australia',   tz: 'Australia/Brisbane',   lat: -27.47, lng: 153.03 },
  { name: 'Melbourne',    country: 'Australia',   tz: 'Australia/Melbourne',  lat: -37.81, lng: 144.96 },
  { name: 'Sydney',       country: 'Australia',   tz: 'Australia/Sydney',     lat: -33.87, lng: 151.21 },
  { name: 'Hobart',       country: 'Australia',   tz: 'Australia/Hobart',     lat: -42.88, lng: 147.33 },
  { name: 'Auckland',     country: 'New Zealand', tz: 'Pacific/Auckland',     lat: -36.85, lng: 174.76 },
  { name: 'Honolulu',     country: 'USA',         tz: 'Pacific/Honolulu',     lat:  21.31, lng: -157.86 },
  { name: 'Anchorage',    country: 'USA',         tz: 'America/Anchorage',    lat:  61.22, lng: -149.90 },
]);

/**
 * Subset of CITIES shown as markers on the world map by default.
 * Chosen for global spread + representation across every major timezone band.
 * @type {ReadonlyArray<string>}
 */
window.FEATURED_CITIES = Object.freeze([
  'Honolulu',  'Anchorage',  'Los Angeles', 'Denver', 'Chicago',   'New York',
  'São Paulo', 'London',     'Paris',       'Berlin', 'Cairo',     'Moscow',
  'Dubai',     'Mumbai',     'Bangkok',     'Singapore', 'Hong Kong',
  'Tokyo',     'Sydney',     'Auckland',    'Hobart',
]);
