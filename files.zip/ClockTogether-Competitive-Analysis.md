# ClockTogether — Competitive Analysis

**Date:** 20 May 2026
**Status:** Pre-launch competitive landscape audit
**Sources:** Web research, G2 reviews, Capterra, Product Hunt, vendor websites

---

## Executive summary

The timezone tool market is **mature but fragmented**. The two heavyweights (WorldTimeBuddy, Every Time Zone) are 13+ years old and feel it — desktop-first UI, no Telegram integration, weak mobile experience. The newer entrants (Spacetime, Clockwise) live inside Slack and don't serve teams that use Telegram. Doodle and Calendly are dominant in adjacent spaces (group polling, 1:1 bookings) but treat timezone display as an afterthought.

**ClockTogether's defensible position:**
- Only mobile-first timezone tool with a live world map on the landing page
- Only product with a working Telegram Mini App + bot-edits-pinned-message
- Only product applying the dual-time display rule (source + your time, day + date)
- Only AU-priced product in AUD for the AU market
- $9 AUD/month undercuts every direct competitor's team tier

**The bet:** Telegram-native teams + mobile-first design + AU-priced is an under-served wedge. The market is large; the incumbents are old; differentiation is real.

---

## Direct competitors (timezone-first tools)

### 1. WorldTimeBuddy ★★★ — biggest direct competitor
- **Founded:** 2011 (Helloka LLC, Berkeley, USA)
- **Pricing:** Free tier + paid tier (~$10/seat/month for teams, 2-week trial)
- **Strengths:** 15 years of SEO dominance, 10-location grid view, Google Calendar integration, iOS + Android apps, drag-and-drop hour tiles, event-page sharing, weekend highlighting, DST warnings
- **Weaknesses:** Desktop-first UI feels dated, no Telegram integration, no PWA, no mobile-first scheduled meetings, no real-time bot for groups, no world map landing page, single-time display (no dual-time rule)
- **User reviews say:** "Drag rows don't lock properly", "Time window can't slide beyond 5pm easily", "Visual interface is great"
- **Threat level:** HIGH — they have SEO dominance for "world clock", "timezone converter"

### 2. Every Time Zone ★★ — premium positioning, no free tier
- **Founded:** 2014 (Slash7 LLC, Pennsylvania, USA)
- **Pricing:** NO free version. Small plan $39/year (~$5/mo USD). Pro plan $119/year (~$10/mo USD). 30-day money-back
- **Strengths:** Clean visual timeline, contact tracking with timezone display, calendar overlay, iCal export (Pro), branded event pages
- **Weaknesses:** Yearly billing only (no monthly), no free tier, no Telegram, no mobile-first, no group sync, no map, USD pricing (no AUD)
- **Threat level:** MEDIUM — premium-priced and yearly-only limits market reach

### 3. timeanddate.com Meeting Planner ★ — free utility, no SaaS
- **Pricing:** Free
- **Strengths:** Free, well-known, comprehensive timezone database, good SEO
- **Weaknesses:** Just a utility, no accounts, no teams, no Telegram, no scheduled meetings, no mobile-first design
- **Threat level:** LOW — different user intent (one-off conversions, not team scheduling)

### 4. Timezone.io ★ — team timezone display
- **Pricing:** Freemium
- **Strengths:** Team-focused, tracks where teammates are
- **Weaknesses:** Maintenance status unclear, no scheduled meetings, no Telegram, no map
- **Threat level:** LOW

---

## Adjacent competitors (broader scheduling tools that include timezone features)

### 5. Calendly — the booking page giant
- **Pricing:** Free / Standard $10-12/mo / Teams $16-20/mo / Enterprise (~$10-15 AUD/mo equivalent)
- **Strengths:** Massive brand recognition, polished booking pages, deep integrations (Zoom, Salesforce, HubSpot, Stripe), automatic timezone detection during booking
- **Weaknesses:** Timezone display is a feature, not the product. No team timezone directory. No Telegram. No world map. Doesn't address "what time is it for them right now?" question
- **Threat level:** LOW for our use case — different problem space (1:1 booking vs team timezone awareness)

### 6. Doodle — group time-finding polls
- **Pricing:** Free with ads / Pro $6.95/mo / Team $14.95/mo
- **Strengths:** Group poll model — find consensus across many people, calendar integration
- **Weaknesses:** Poll-based (not continuous), no live timezone display, no Telegram, no map. Different problem space
- **Threat level:** LOW — different model

### 7. Spacetime — Slack-native timezone bot
- **Pricing:** Free trial available, paid tiers
- **Strengths:** Slack-native (lives where the team chats), work hours per teammate, "@spacetime 3pm" command
- **Weaknesses:** Slack only — no Telegram, no web app, no PWA, no map. Effectively zero overlap with our Telegram users
- **Threat level:** MEDIUM (in concept) but LOW for our market (Telegram teams)

### 8. Clockwise — AI calendar optimisation
- **Pricing:** Free / paid tiers
- **Strengths:** AI-driven calendar moves meetings to optimal times
- **Weaknesses:** Calendar optimisation tool, not a timezone tool. Different category
- **Threat level:** LOW — different product

---

## Telegram-space competitors

### 9. Local Time bot for Telegram — closest Telegram competitor
- **Pricing:** Free (ad-supported)
- **Strengths:** Free, well-known in Telegram community since 2020, shows local times for all group members
- **Weaknesses:** Display only — no scheduled meetings, no conversion, no Mini App, no web app, no PWA, no map, no accounts
- **Threat level:** MEDIUM — they own the "Telegram timezone bot" search but the feature gap to ClockTogether is enormous

### 10. @the_timezone_bot — utility bot
- **Pricing:** Free
- **Strengths:** Time conversion + countdowns
- **Weaknesses:** Inline utility only, no team features, no Mini App
- **Threat level:** LOW

### 11. MeetingBossBot — meeting time optimiser bot
- **Pricing:** Unknown (small bot)
- **Strengths:** Auto-selects best meeting time across participants
- **Weaknesses:** Small user base, no map, no web companion app
- **Threat level:** LOW

### 12. Smart Scheduler Bot — natural language reminders
- **Pricing:** Free / self-hosted
- **Strengths:** Natural language time parsing
- **Weaknesses:** Personal reminders, not team timezone coordination
- **Threat level:** LOW

---

## Feature comparison matrix

| Feature | ClockTogether | WorldTimeBuddy | Every Time Zone | Calendly | Local Time Bot |
|---|---|---|---|---|---|
| Free tier | ✅ Generous | ✅ Basic | ❌ | ✅ Limited | ✅ |
| Live world map on landing | ✅ Real D3 + atlas | ❌ | ❌ | ❌ | ❌ |
| Free converter on landing | ✅ No signup | ✅ | ❌ | ❌ | ❌ |
| Dual-time display rule | ✅ | ❌ | Partial | Partial | Partial |
| Day + date + time + zone | ✅ | Partial | Partial | Partial | Partial |
| Up to 7 personal zones | ✅ | ✅ 10 zones | ✅ | N/A | ❌ |
| Scheduled meetings | ✅ 7 personal + 7/team | ❌ | Limited | ✅ | ❌ |
| Team directory live times | ✅ | ❌ | ✅ Pro | ❌ | ✅ Basic |
| Status dots (working/asleep) | ✅ | ❌ | ❌ | ❌ | ❌ |
| Telegram Mini App | ✅ | ❌ | ❌ | ❌ | N/A (bot only) |
| Bot edits pinned message | ✅ Premium | ❌ | ❌ | ❌ | ❌ |
| PWA install | ✅ | ❌ | ❌ | ❌ | ❌ |
| iOS / Android app | ✅ via PWA | ✅ Native | ❌ | ✅ | ❌ |
| Calendar integration (.ics) | ✅ Premium | ✅ | ✅ Pro | ✅ | ❌ |
| Auto-detect home timezone | ✅ | ✅ | ✅ | ✅ | ✅ |
| AUD pricing | ✅ $9 AUD | ❌ USD | ❌ USD | ❌ USD | Free |
| Mobile-first design | ✅ | ❌ Desktop-first | ❌ | ✅ | ✅ |

**Cells where ClockTogether is alone with a green tick:** 6 — the live map landing, dual-time rule, full format rule, status dots, Telegram Mini App, bot-edits-pin.

---

## Pricing positioning

Converted to a common reference (USD/month equivalent):

| Product | Free tier? | Paid tier (entry) | Paid tier (teams) |
|---|---|---|---|
| timeanddate.com | Yes (full) | — | — |
| Local Time Bot (Telegram) | Yes | — | — |
| ClockTogether | **Yes (full converter)** | **$6 USD ($9 AUD)** | **$6 USD ($9 AUD)** |
| Doodle | Yes (with ads) | $6.95 | $14.95 |
| Spacetime | Trial only | ~$5-10 | ~$10-15 |
| WorldTimeBuddy | Yes | ~$5-10 | ~$10/seat |
| Every Time Zone | No | $5 (yearly) | $10 (yearly) |
| Calendly | Yes (limited) | $10-12 | $16-20 |

**ClockTogether at $9 AUD ($6 USD)** sits in the budget tier. Cheapest paid product in the direct-competitor set. Risks:
- Could signal "low value" — some buyers equate price with quality
- Hard to upsell from $9 to $19 later (price anchoring)
- Tight margins if customer support time becomes significant

**Counter-argument for $9:**
- Frictionless conversion from free at $9/mo (people impulse-buy at that price)
- Differentiates as "no-nonsense AU pricing" against USD-only competitors
- Scales via volume, not per-customer revenue
- Can launch annual at $90/year (2 months free) to lift LTV without changing perceived monthly price

**Alternative considerations:**
- **$15-19 AUD/month** would put you mid-market, closer to WTB and ETZ team tiers, more "serious tool" positioning
- **$29 AUD/month for "Team" tier** could be a future upsell with bigger team caps and the Telegram bot features

Recommendation: stay at $9 for launch, monitor conversion + churn for 60 days, then test a $19 tier with bigger features. Easier to raise prices than lower them once people are paying.

---

## SEO landscape

The high-traffic keywords in this space, ranked by competitor dominance:

| Keyword | Top 3 dominators | Difficulty to crack |
|---|---|---|
| "world clock" | timeanddate.com, WTB, Google built-in | Very high |
| "time zone converter" | timeanddate.com, WTB, Savvy Time | Very high |
| "meeting planner timezone" | WTB, timeanddate.com, Calendly | High |
| "[country] time" / "[city] time" | timeanddate.com, Google direct, WTB | Very high |
| "team timezone tool" | WTB, Timezone.io | Medium |
| "Telegram timezone bot" | Local Time Bot, niche bots | LOW |
| "Telegram team meeting scheduler" | (almost no one) | VERY LOW |
| "world clock app Australia" | Some local sites | LOW |
| "remote team timezone Australia" | (almost no one) | VERY LOW |

**SEO strategy implication:** don't compete head-on with timeanddate.com or WTB on "world clock" — they have 15+ years of backlinks. Instead, win the long-tail Telegram-specific and Australia-specific terms. Build programmatic SEO pages like:
- /telegram-timezone-bot
- /au/team-meeting-scheduler
- /telegram/[city]-time
- /au/[city]-to-[city]-time-converter

---

## Differentiation summary

ClockTogether's six clear "alone in the green" cells from the feature matrix:

1. **Live world map on landing page** — every competitor has a list view or a grid. None have a real D3 + world-atlas live map
2. **Dual-time display rule** — every competitor shows the converted time. ClockTogether shows both source AND your time with equal weight, every time, everywhere
3. **Full format rule (day + date + time + zone)** — competitors abbreviate; ClockTogether is explicit
4. **Status dots on team directory** — instant "is now a good time to call them?" answer no competitor offers
5. **Telegram Mini App** — fully native, not just a bot. Lives where the team already talks
6. **Bot edits pinned message** — when meeting time changes, the pinned group message updates automatically. Unique in the market

**The product brief for the landing page CTA copy should lean on these six.** Particularly the map (visceral, demoable) and the bot-edits-pin (no one else does it).

---

## Threats to monitor

1. **WorldTimeBuddy launching a mobile-first redesign** — they have the brand and SEO. If they invest in mobile, the differentiation narrows
2. **Calendly adding "team timezone tab"** — they have the team distribution. One feature drop could neutralise a chunk of the value prop
3. **Telegram adding native scheduled-meeting reminders** — possible but unlikely soon. Telegram tends to add primitives, not products
4. **Free Telegram bot adding scheduled meetings** — easier to do; would commoditise the base feature. ClockTogether's defence is the PWA + map + dual-time rule

---

## Recommendations

### Pre-launch (must-do before Phase 2 build starts)
1. **Trademark "ClockTogether" in AU class 42** (~$250 AUD via IP Australia) — protect the name now
2. **Domain defensives** — buy clocktogether.io and clocktogether.app for ~$30/each to block lookalikes
3. **Keep $9 AUD pricing for launch** — revisit at 60 days based on conversion data
4. **Position Telegram Mini App in marketing copy** — this is your real moat
5. **Don't compete on "world clock" SEO** — own the Telegram + Australia + team-timezone long tail
6. **Use "dual-time display" + "day-rollover warning" as visual demos in the landing copy** — competitors don't have these and the demos are striking

### Post-launch (months 1-3)
1. **Capture real testimonials** — current ones are placeholder. Goal: 20 real users → 5 real testimonials within 60 days
2. **Build programmatic SEO pages** — country/city/timezone combinations auto-generated from the cities database
3. **Submit to directories** — Product Hunt, Tracxn, SaaSHub, G2 (paid listings later)
4. **Monitor WTB and ETZ for response moves** — if they introduce a free Telegram bot, escalate fast

### Months 3-6
1. **Test $19 AUD "Team" tier** with bigger team caps + bot features
2. **Add NZ + UK pricing in local currency** (NZD $9.50, GBP £5.50)
3. **Consider freemium AI features** — natural language scheduling ("schedule a call with Sarah at her usual morning time") would extend the moat

---

## Final read

The timezone tool space is **served but stale**. The dominant players are old. The newcomers are platform-specific (Slack-only) and ignore Telegram. The mobile experience across the category is weak. AU-specific products are basically non-existent.

ClockTogether's combination of mobile-first PWA + Telegram Mini App + live world map + dual-time rule + $9 AUD pricing is a real wedge into a real market. The features alone won't win — the execution (especially the map and the bot integration) needs to be polished and demoable from day one. The work done so far (landing page, spec, locked design rules) hits that bar.

**The market is open. The differentiation is real. Execute Phase 2 and ship.**
