# ClockTogether — Landing Page Deployment

## What's in this package

Three production-ready files that together make the landing page with a real world map and free meeting converter:

| File | Size | Purpose |
|---|---:|---|
| `index.html` | ~33 KB | Full landing page — structure, all styles inline, OG / Twitter / favicon meta |
| `app.js`     | ~23 KB | Map rendering, day/night terminator, live ticker, converter logic |
| `cities.js`  | ~7 KB  | Frozen database of 58 cities with IANA timezones + coordinates |

**Total:** ~63 KB of code, plus ~450 KB of CDN dependencies (Luxon + D3 + topojson-client + world-atlas) loaded once and cached forever.

## What it does

1. **Real world map** — full country shapes from world-atlas (TopoJSON), drawn via D3 in Equirectangular projection
2. **Real day/night terminator** — calculated from the actual subsolar point (where the sun is currently overhead). Refreshes every minute, aligned to the real minute boundary
3. **Live city clocks** — 21 featured cities show their current local time on the map, colour-coded amber for day, coral for dawn/dusk, cool blue for night
4. **Auto-detected home marker** — reads the browser's IANA timezone, finds the nearest featured city, highlights it in teal with a pulse
5. **Click a city** → scrolls to converter and pre-fills it with that city as source
6. **Free converter** — pick any city, any date, any time → see it in your own timezone with full day + date + time + zone format, day-rollover warning if dates differ, copy-to-clipboard

No signup required for any of this. Everything runs client-side. No PHP, no database, no API keys.

## How to test locally

Easiest — open `index.html` directly in any modern browser. Works straight from the file system.

If the world map doesn't load from `file://` (Safari blocks CDN fetches in this mode), serve it with a local web server:

```bash
cd clocktogether-build/
python3 -m http.server 8000
# Then open http://localhost:8000 in your browser
```

## How to deploy to Speed Reaper

1. **cPanel → File Manager → public_html** on clocktogether.com
2. **Upload all three files** to public_html/
3. **Done.** Visit https://clocktogether.com

No build step. No bundler. No config. Just three static files.

## CDN dependencies (loaded automatically by the browser)

The page pulls these from jsDelivr on first load (~450 KB total, cached after):

- **Luxon 3.5** — IANA timezone math and DST handling
- **D3 v7** — SVG and geo projection
- **topojson-client 3** — TopoJSON to GeoJSON conversion
- **world-atlas v2** — country shape data
- **Google Fonts** — Instrument Serif + DM Sans + JetBrains Mono

## (Optional) Host the map data locally for zero CDN dependency

Eliminates the half-second "Loading map…" state on first visit:

```bash
curl -o countries-110m.json https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json
```

Upload the JSON to `public_html/` alongside the three main files. Then edit `app.js`:

```js
// Change this:
const ATLAS_URL = 'https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json';
// To this:
const ATLAS_URL = '/countries-110m.json';
```

The constant lives at the top of `app.js` for easy editing.

## What's polished and production-ready

The codebase has been audited and cleaned. Highlights:

- **`app.js` is fully documented** with JSDoc on every public function, hoisted constants, cached DOM references, clearly delineated sections
- **`cities.js` is immutable** (Object.freeze) so the data can't be accidentally mutated at runtime
- **Inline favicon** — SVG embedded directly, no extra file needed
- **Apple touch icon** included for iOS home-screen installs
- **Open Graph + Twitter meta tags** for social card sharing
- **Theme-color meta** — mobile browser chrome tints with brand teal
- **`en-AU` locale** declared on `<html>` for proper screen reader pronunciation
- **`aria-label`s** on the nav, brand link, and decorative elements hidden from assistive tech
- **`type="button"`** on form buttons so they don't accidentally submit a parent `<form>` if one is added later
- **No `console.log`s, no TODOs, no commented-out code, no inline event handlers**
- **No global pollution** beyond `CITIES` and `FEATURED_CITIES` (intentional, documented)
- **Aligned-to-minute ticker** so visible clock changes happen at the real minute boundary

## What's NOT in this build yet (Phase 2 work)

These come once the 7 critical decisions are locked and backend work begins:

- Signup / login / account pages (currently `#signup` is a placeholder anchor)
- Stripe checkout + webhook
- Team creation + invitation flow
- Scheduled meetings tab (real, working — only HTML mockup exists)
- Team Directory tab (real, working — only HTML mockup exists)
- Telegram Mini App integration
- PWA manifest + service worker + multi-size app icons
- Email templates + Resend integration
- Privacy + Terms pages
- robots.txt + sitemap.xml
- Analytics (Plausible / Fathom)

Phase 1 (this build) is **capture intent + demonstrate value**. Phase 2 wires the signup flow and turns visitors into paid teams.

## Recommended next steps

1. **Test in browser locally** — confirm the map loads, click a city, run a conversion, check copy-to-clipboard
2. **Test on mobile** — iOS Safari and Android Chrome both
3. **Upload to Speed Reaper** — 5 minutes
4. **Update Telegram BotFather** — point `@MeetingTimeConverterbot` web app URL to clocktogether.com
5. **Add Plausible analytics** — single script tag for clean privacy-friendly metrics
6. **Lock the 7 critical product decisions** — see `ClockTogether-Master-Spec.md` audit section
7. **Begin Phase 2 build** — auth + database

## Customisation reference

**Change brand colour:** edit `:root` in `index.html` (the `--teal*` variables) **and** `COLOURS.home` in `app.js`. They're documented as needing to be kept in sync.

**Add a city:** append to `CITIES` in `cities.js`. To also show it on the map by default, add the name to `FEATURED_CITIES`.

**Change refresh cadence:** edit `REFRESH_MS` constant near the top of `app.js`.

**Change headline:** edit `<h1>What time is it<br><em>over there?</em></h1>` in `index.html`.

**Change pricing:** Premium price lives in the pricing section of `index.html`, search for `$9`.

---

That's the landing page. Tested, audited, cleaned, documented, deployable.
